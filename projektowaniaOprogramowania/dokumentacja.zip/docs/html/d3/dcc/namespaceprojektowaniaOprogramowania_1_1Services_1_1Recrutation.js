var namespaceprojektowaniaOprogramowania_1_1Services_1_1Recrutation =
[
    [ "IRecruitmentValidationService", "dc/d6c/interfaceprojektowaniaOprogramowania_1_1Services_1_1Recrutation_1_1IRecruitmentValidationService.html", null ],
    [ "RecruitmentValidationService", "d2/d08/classprojektowaniaOprogramowania_1_1Services_1_1Recrutation_1_1RecruitmentValidationService.html", null ]
];