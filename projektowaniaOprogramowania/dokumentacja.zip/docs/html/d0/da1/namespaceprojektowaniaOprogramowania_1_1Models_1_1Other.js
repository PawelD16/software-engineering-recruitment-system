var namespaceprojektowaniaOprogramowania_1_1Models_1_1Other =
[
    [ "PracownikDzialuRekrutacjiNaPodanieKandydataModel", "d4/d15/classprojektowaniaOprogramowania_1_1Models_1_1Other_1_1PracownikDzialuRekrutacjiNaPodanieKandydataModel.html", null ]
];