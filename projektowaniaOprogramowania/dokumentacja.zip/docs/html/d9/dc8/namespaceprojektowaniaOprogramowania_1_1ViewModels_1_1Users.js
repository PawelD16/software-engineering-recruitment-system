var namespaceprojektowaniaOprogramowania_1_1ViewModels_1_1Users =
[
    [ "KandydatModel", "d6/da6/classprojektowaniaOprogramowania_1_1ViewModels_1_1Users_1_1KandydatModel.html", null ],
    [ "OsobaModel", "d4/dad/classprojektowaniaOprogramowania_1_1ViewModels_1_1Users_1_1OsobaModel.html", null ],
    [ "PracownikDzialuRekrutacjiModel", "de/d1b/classprojektowaniaOprogramowania_1_1ViewModels_1_1Users_1_1PracownikDzialuRekrutacjiModel.html", null ],
    [ "PracownikModel", "da/d6f/classprojektowaniaOprogramowania_1_1ViewModels_1_1Users_1_1PracownikModel.html", null ]
];