var namespaceprojektowaniaOprogramowania_1_1Migrations =
[
    [ "Init", "d7/dc7/classprojektowaniaOprogramowania_1_1Migrations_1_1Init.html", null ],
    [ "MyDbContextModelSnapshot", "da/d7d/classprojektowaniaOprogramowania_1_1Migrations_1_1MyDbContextModelSnapshot.html", null ]
];