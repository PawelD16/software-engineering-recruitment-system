var namespaceprojektowaniaOprogramowania_1_1Controllers =
[
    [ "HomeController", "dc/d95/classprojektowaniaOprogramowania_1_1Controllers_1_1HomeController.html", null ],
    [ "KierunekNaPodaniuController", "d1/d4a/classprojektowaniaOprogramowania_1_1Controllers_1_1KierunekNaPodaniuController.html", "d1/d4a/classprojektowaniaOprogramowania_1_1Controllers_1_1KierunekNaPodaniuController" ],
    [ "OsobaController", "d8/d49/classprojektowaniaOprogramowania_1_1Controllers_1_1OsobaController.html", null ],
    [ "PodanieController", "d4/df8/classprojektowaniaOprogramowania_1_1Controllers_1_1PodanieController.html", null ],
    [ "PracownikEdycjaController", "d7/d69/classprojektowaniaOprogramowania_1_1Controllers_1_1PracownikEdycjaController.html", null ],
    [ "PredykcjaController", "dd/d1c/classprojektowaniaOprogramowania_1_1Controllers_1_1PredykcjaController.html", null ],
    [ "PrzegladController", "d9/d8a/classprojektowaniaOprogramowania_1_1Controllers_1_1PrzegladController.html", null ],
    [ "RekrutacjaController", "d1/d79/classprojektowaniaOprogramowania_1_1Controllers_1_1RekrutacjaController.html", null ]
];