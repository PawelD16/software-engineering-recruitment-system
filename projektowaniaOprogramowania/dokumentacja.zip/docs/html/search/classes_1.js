var searchData=
[
  ['errorviewmodel_0',['ErrorViewModel',['../d0/d17/classprojektowaniaOprogramowania_1_1Models_1_1ErrorViewModel.html',1,'projektowaniaOprogramowania::Models']]]
];
