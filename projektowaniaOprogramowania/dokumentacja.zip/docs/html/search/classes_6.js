var searchData=
[
  ['ocenamodel_0',['OcenaModel',['../dd/d59/classprojektowaniaOprogramowania_1_1ViewModels_1_1OcenaModel.html',1,'projektowaniaOprogramowania::ViewModels']]],
  ['ocenazprzedmiotem_1',['OcenaZPrzedmiotem',['../d3/d58/classprojektowaniaOprogramowania_1_1ViewModels_1_1OcenaZPrzedmiotem.html',1,'projektowaniaOprogramowania::ViewModels']]],
  ['osobacontroller_2',['OsobaController',['../d8/d49/classprojektowaniaOprogramowania_1_1Controllers_1_1OsobaController.html',1,'projektowaniaOprogramowania::Controllers']]],
  ['osobamodel_3',['OsobaModel',['../d4/dad/classprojektowaniaOprogramowania_1_1ViewModels_1_1Users_1_1OsobaModel.html',1,'projektowaniaOprogramowania::ViewModels::Users']]]
];
