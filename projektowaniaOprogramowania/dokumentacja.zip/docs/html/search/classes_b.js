var searchData=
[
  ['wszystkieinformacjepodaniaviewmodel_0',['WszystkieInformacjePodaniaViewModel',['../de/d91/classprojektowaniaOprogramowania_1_1ViewModels_1_1WszystkieInformacjePodaniaViewModel.html',1,'projektowaniaOprogramowania::ViewModels']]],
  ['wydzialmodel_1',['WydzialModel',['../df/d17/classprojektowaniaOprogramowania_1_1ViewModels_1_1CollegeStructures_1_1WydzialModel.html',1,'projektowaniaOprogramowania::ViewModels::CollegeStructures']]]
];
