var searchData=
[
  ['aspnetcore_0',['AspNetCore',['../d4/d38/namespaceAspNetCore.html',1,'']]]
];
