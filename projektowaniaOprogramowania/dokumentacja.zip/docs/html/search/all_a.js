var searchData=
[
  ['sessionwrapper_0',['SessionWrapper',['../da/dc3/classprojektowaniaOprogramowania_1_1Services_1_1SessionWrapper.html',1,'projektowaniaOprogramowania::Services']]],
  ['startup_1',['Startup',['../d5/d95/classprojektowaniaOprogramowania_1_1Startup.html',1,'projektowaniaOprogramowania']]]
];
