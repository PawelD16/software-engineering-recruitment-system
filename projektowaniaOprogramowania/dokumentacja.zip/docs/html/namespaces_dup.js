var namespaces_dup =
[
    [ "AspNetCore", "d4/d38/namespaceAspNetCore.html", "d4/d38/namespaceAspNetCore" ],
    [ "projektowaniaOprogramowania", "d8/d9d/namespaceprojektowaniaOprogramowania.html", "d8/d9d/namespaceprojektowaniaOprogramowania" ]
];