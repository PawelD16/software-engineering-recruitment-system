var namespaceprojektowaniaOprogramowania_1_1Services =
[
    [ "Recrutation", "d3/dcc/namespaceprojektowaniaOprogramowania_1_1Services_1_1Recrutation.html", "d3/dcc/namespaceprojektowaniaOprogramowania_1_1Services_1_1Recrutation" ],
    [ "ISessionWrapper", "d9/da7/interfaceprojektowaniaOprogramowania_1_1Services_1_1ISessionWrapper.html", null ],
    [ "PodanieService", "d2/d37/classprojektowaniaOprogramowania_1_1Services_1_1PodanieService.html", null ],
    [ "PunktyRekrutacyjneService", "df/d6e/classprojektowaniaOprogramowania_1_1Services_1_1PunktyRekrutacyjneService.html", null ],
    [ "SessionWrapper", "da/dc3/classprojektowaniaOprogramowania_1_1Services_1_1SessionWrapper.html", null ]
];