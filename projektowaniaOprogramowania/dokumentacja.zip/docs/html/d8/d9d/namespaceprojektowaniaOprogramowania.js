var namespaceprojektowaniaOprogramowania =
[
    [ "Controllers", "d7/df3/namespaceprojektowaniaOprogramowania_1_1Controllers.html", "d7/df3/namespaceprojektowaniaOprogramowania_1_1Controllers" ],
    [ "Migrations", "d2/dde/namespaceprojektowaniaOprogramowania_1_1Migrations.html", "d2/dde/namespaceprojektowaniaOprogramowania_1_1Migrations" ],
    [ "Models", "d6/d4b/namespaceprojektowaniaOprogramowania_1_1Models.html", "d6/d4b/namespaceprojektowaniaOprogramowania_1_1Models" ],
    [ "Services", "d8/d08/namespaceprojektowaniaOprogramowania_1_1Services.html", "d8/d08/namespaceprojektowaniaOprogramowania_1_1Services" ],
    [ "ViewModels", "da/dc5/namespaceprojektowaniaOprogramowania_1_1ViewModels.html", "da/dc5/namespaceprojektowaniaOprogramowania_1_1ViewModels" ],
    [ "Program", "d3/db7/classprojektowaniaOprogramowania_1_1Program.html", null ],
    [ "Startup", "d5/d95/classprojektowaniaOprogramowania_1_1Startup.html", null ]
];