var namespaceprojektowaniaOprogramowania_1_1ViewModels_1_1CollegeStructures =
[
    [ "KierunekModel", "dd/d2a/classprojektowaniaOprogramowania_1_1ViewModels_1_1CollegeStructures_1_1KierunekModel.html", null ],
    [ "MiastoModel", "d6/de0/classprojektowaniaOprogramowania_1_1ViewModels_1_1CollegeStructures_1_1MiastoModel.html", null ],
    [ "WydzialModel", "df/d17/classprojektowaniaOprogramowania_1_1ViewModels_1_1CollegeStructures_1_1WydzialModel.html", null ]
];