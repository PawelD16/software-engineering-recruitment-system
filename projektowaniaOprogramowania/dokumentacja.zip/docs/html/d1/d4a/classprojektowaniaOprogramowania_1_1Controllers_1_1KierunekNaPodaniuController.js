var classprojektowaniaOprogramowania_1_1Controllers_1_1KierunekNaPodaniuController =
[
    [ "WyslijPodanie", "d1/d4a/classprojektowaniaOprogramowania_1_1Controllers_1_1KierunekNaPodaniuController.html#a22c0d344868e29561e18f6485e873475", null ]
];